<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learn Hackathon</title>
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
    <header class="main">

    <footer class="contact"> 
        <div class="contact-heading">
            <h1>Sign in</h1>
            
        </div>
        <form action="signindb.php" method="post">
            <input type="text" name="username" placeholder="Your username"/>
            <input type="password" name="password" placeholder="Enter your password"/>
            <button class="main-btn contact-btn" type="submit">Continue</button>
        </form>

        <div class="contact-heading">
            <p>Don't have an account ? Signup now!</p>
            <a href="signup.php">Signup</a>
        </div>
    </footer>
</body>
</html>